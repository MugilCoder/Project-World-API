﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebApplication1.Data;
using WebApplication1.DTO.Country;
using WebApplication1.Models;
using WebApplication1.Reprository.IRepository;

namespace WebApplication1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CountryController : ControllerBase
    {
        public readonly ICountryRepository _countryRepository;

        private readonly IMapper _mapper;

        private readonly ILogger<CountryController> _logger;

        public CountryController(ICountryRepository countryRepository, IMapper mapper, ILogger<CountryController> logger)
        {
            _countryRepository = countryRepository;
            _mapper = mapper;
            _logger = logger;
        }

        [HttpGet]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<ActionResult<IEnumerable<CountryDto>>> GetAll()
        {
            var countries = await _countryRepository.GetAll();

            if(countries == null)
            {
                return NoContent();
            }

            var countriesDto = _mapper.Map<List<CountryDto>>(countries);
            return Ok(countriesDto);
        }

        [HttpGet("{id:int}")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status200OK)]

        public async Task<ActionResult<CountryDto>> GetById(int id)
        {
            var countries = await _countryRepository.Get(id);  
            if (countries == null)
            {
                _logger.LogError($"Error while try to get record id: {id}");
                return NoContent();
            }
            var countryDto = _mapper.Map<CountryDto>(countries);
            return Ok(countryDto);
        }

        [HttpPost]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status409Conflict)]
        public async Task<ActionResult<CreateCountryDTO>> Create([FromBody] CreateCountryDTO countryDto)
        {
            var result = _countryRepository.IsRecordExists(x=>x.CountryName == countryDto.CountryName);

            if (result)
            {
                return Conflict("Country already Exists in Database");
            }

            var country = _mapper.Map<Country>(countryDto);

           await  _countryRepository.Create(country);
            return CreatedAtAction("GetById", new { id = country.Id }, country);
        }

        [HttpPut]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult<Country>> Update(int id, [FromBody] UpdateCountryDto countryDto)
        { 
            if(countryDto == null || id != countryDto.Id)
            {
                return BadRequest();
            }

            var country = _mapper.Map<Country>(countryDto);

            await _countryRepository.Update(country);
            return NoContent();
        }

        [HttpDelete("{id:int}")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult> DeleteById(int id)
        {
            if(id == 0)
                return BadRequest();

            var country = await _countryRepository.Get(id);
            if (country == null)
            {
                NotFound();
            }
            await _countryRepository.Delete(country);
            return NoContent();
        }
    }
}
