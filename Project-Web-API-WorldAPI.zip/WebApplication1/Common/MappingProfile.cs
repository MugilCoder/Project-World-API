﻿using AutoMapper;
using WebApplication1.DTO.Country;
using WebApplication1.DTO.States;
using WebApplication1.Models;

namespace WebApplication1.Common
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            //Source, Destination
            CreateMap<Country, CreateCountryDTO> ().ReverseMap();
            CreateMap<Country, CountryDto>().ReverseMap();
            CreateMap<Country, UpdateCountryDto>().ReverseMap();

            CreateMap<States, CreateStatesDto>().ReverseMap();
            CreateMap<States, StatesDto>().ReverseMap();
            CreateMap<States, UpdateStatesDto>().ReverseMap();

        }
    }
}
