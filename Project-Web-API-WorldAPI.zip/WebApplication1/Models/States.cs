﻿namespace WebApplication1.Models
{
    public class States
    {
        public int Id { get; set; }
        public string StateName { get; set; }
        public string Population { get; set; }
        public int CountryId { get; set; }
        public Country Country { get; set; }

    }
}
