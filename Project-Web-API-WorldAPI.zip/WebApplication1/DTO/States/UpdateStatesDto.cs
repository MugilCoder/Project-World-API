﻿namespace WebApplication1.DTO.States
{
    public class UpdateStatesDto
    {
        public int Id { get; set; }
        public string StateName { get; set; }
        public string Population { get; set; }
        public int CountryId { get; set; }
    }
}
