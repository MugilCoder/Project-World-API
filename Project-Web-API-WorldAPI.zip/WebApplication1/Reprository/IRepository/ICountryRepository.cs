﻿using WebApplication1.Data;
using WebApplication1.Models;

namespace WebApplication1.Reprository.IRepository
{
    public interface ICountryRepository : IGenericRepository<Country>
    {
        Task Update(Country entity);
    }
}
