﻿using WebApplication1.Models;

namespace WebApplication1.Reprository.IRepository
{
    public interface IStatesRepository : IGenericRepository<States>
    {      
        Task Update(States entity);     

    }
}
