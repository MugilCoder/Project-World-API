﻿using Microsoft.EntityFrameworkCore;
using WebApplication1.Data;
using WebApplication1.Models;
using WebApplication1.Reprository.IRepository;

namespace WebApplication1.Reprository
{
    public class CountryRepository : GenericRepository<Country>,ICountryRepository
    {
        private readonly ApplicationDbContext _dbContext;

        public CountryRepository(ApplicationDbContext dbContext) : base(dbContext)
        {
            _dbContext = dbContext;
        }      
        public async Task Update(Country entity)
        {
            _dbContext.countries.Update(entity);
            _dbContext.SaveChanges();
        }
    }
}
