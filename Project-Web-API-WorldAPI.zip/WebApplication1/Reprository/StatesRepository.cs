﻿using Microsoft.EntityFrameworkCore;
using WebApplication1.Data;
using WebApplication1.Models;
using WebApplication1.Reprository.IRepository;

namespace WebApplication1.Reprository
{
    public class StatesRepository : GenericRepository<States>, IStatesRepository
    {
        public readonly ApplicationDbContext _dbContext;

        public StatesRepository(ApplicationDbContext dbContext) : base(dbContext)
        {
            _dbContext = dbContext;
        }     
        public async Task Update(States entity)
        {
            _dbContext.States.Update(entity);
            _dbContext.SaveChanges();
        }
    }
}
